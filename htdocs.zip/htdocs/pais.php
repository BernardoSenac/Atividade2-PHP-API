<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Detalhes do País</title>
</head>
<?php
    $url = "https://restcountries.com/v3.1/alpha/" . $_GET['codigo'];

    $curl = curl_init();

    curl_setopt_array($curl, [
        CURLOPT_URL => $url,
        CURLOPT_RETURNTRANSFER => true
    ]);

    $response = curl_exec($curl);

    curl_close($curl);

    $pais = json_decode($response, true)[0];
?>
<body>
    <h1>Detalhes do País</h1>
    <p>Nome do País: <?php echo $pais['name']['common']; ?></p>
    <p>Continente: <?php echo $pais['region']; ?></p>
    <p>População: <?php echo number_format($pais['population']); ?></p>
    <p>Bandeira: </p>
    <img src="<?php echo $pais['flags']['svg']; ?>" alt="Bandeira de <?php echo $pais['name']['common']; ?>" width="200">
    <br><br>
    <a href="index.php">Voltar para a Lista de Países</a>
</body>
</html>